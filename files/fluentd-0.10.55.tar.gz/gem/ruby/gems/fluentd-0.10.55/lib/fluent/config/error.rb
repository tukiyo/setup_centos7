module Fluent
  class ConfigError < StandardError
  end

  class ConfigParseError < ConfigError
  end
end
