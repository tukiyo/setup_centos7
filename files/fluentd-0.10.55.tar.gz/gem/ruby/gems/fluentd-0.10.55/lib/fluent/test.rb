require 'test/unit'
require 'fluent/load'
require 'fluent/test/base'
require 'fluent/test/input_test'
require 'fluent/test/output_test'

$log ||= Fluent::Log.new(Fluent::Test::DummyLogDevice.new)
