module Fluent

  VERSION = '0.10.55'

end
