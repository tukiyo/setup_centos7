module Fluent
  TextParser.register_template('known', /^(?<message>.*)$/)
end
