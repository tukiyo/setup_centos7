module Coolio
  VERSION = "1.2.4"
  
  def self.version
    VERSION
  end
end
