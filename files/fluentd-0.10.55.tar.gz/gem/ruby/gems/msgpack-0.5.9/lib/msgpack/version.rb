module MessagePack
	VERSION = "0.5.9"
end
