require File.expand_path('../../sigdump', __FILE__)

Sigdump.setup

